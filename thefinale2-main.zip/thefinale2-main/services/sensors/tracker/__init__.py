"""Person tracking module"""
from .person_tracker import PersonTracker

__all__ = ['PersonTracker']
