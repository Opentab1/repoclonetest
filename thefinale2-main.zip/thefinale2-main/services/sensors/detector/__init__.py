"""Person detection module"""
from .person_detector import PersonDetector

__all__ = ['PersonDetector']
